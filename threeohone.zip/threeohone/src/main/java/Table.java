import javafx.event.Event;

import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;
//@Author:Akin_Parkan
public class Table {
    private String tableID;
    private int noOfPlayers;
    private int age;
    private int turn;
    private Deck age1Deck;
    //private Deck age2Deck;
    //private Deck age3Deck;
    //private Deck magicCardDeck;
    private List<Card> discardedCards;
    //private Card hand[noOfPlayers][7];
    private List<WonderBoard> diceRollers;
    private String diceRollWinner;
    private Card diceRollCard;
    //private ScoreBoard scoreboard
    private LinkedBlockingQueue<Event> eventQueue;
    private Map<String, Socket> playerChannel;
    private HashMap<String, WonderBoard> wonders;
    private String owner;
    private boolean rollDice;
    private List<String> playerIDs;
    private DeckFactory deckFactory;
    //private TableNotifier notifier


    public Table(String tableID, String owner) {
        this.tableID = tableID;
        this.noOfPlayers = 1;
        this.owner = owner;
        age = 1;
        playerIDs = new ArrayList<>();
        playerIDs.add(owner);
        //age1Deck = new Deck(holdDeck1,"Deck1");
        //hand initialize edilecek
    }

    public void playerJoined(String playerID, Socket socket) throws Exception
    {

        if(playerIDs.contains(playerID))
        {
            throw new Exception("playerID is taken ");
        }
        else {
            noOfPlayers++;
            playerIDs.add(playerID);
        }
    }
    public void init(int noOfPlayer, Deck[] decks)
    {}
    public void startTable( Deck age1Deck, Deck age2Deck, Deck age3Deck)
    {
        this.age1Deck = age1Deck;
        //contioue
    }
    public void rollDice()
    {}
    public void addWonder()
    {}
    public void pickMagicCard(String wonderID)
    {}
    public void changeHand()
    {}
   // public getHandRequest(String wonderID)
    //{}
  //  public WonderBoard viewStateRequest()
   // {}
    public void diceRollRequest(String wonderID)
    {}
    public void notifyPlayers()
    {}
    public void playAge()
    {}
    public void lockAction(Action action)
    {}
   // public boolean isPossible(Action action)
    //{}
    public void playTurn()
    {}
}
/*

private string tableID
	String for holding the ID of this table.
private int noOfPlayers
	Int for holding the number of players.
private int age
	Int for holding the current age of the table.
private int turn
	Int for holding the current turn of the table.
private Deck age1Deck
	Deck for holding the references of the first age cards which are in the house.
private Deck age2Deck
	Deck for holding the references of the second age cards which are in the house.
private Deck age3Deck
	Deck for holding the references of the third age cards which are in the house.
private Deck magicCardDeck
	Deck for holding the references of the magic cards which are in the house.
private List<Card> discardedCards
	List for holding the discarded cards through the game.
private Card hand[noOfPlayers][7]
	Two dimensional array for holding all the cards which are at the players’ hands in the current turn.
private List<WonderBoard> diceRollers
	List of wonderboards, which means players who want to roll a dice in that turn.
private String diceRollWinner
	String for holding the winner of dice roll game.
private Card diceRollCard
	Card which holds the reward of the dice roll game winner.
private ScoreBoard scoreboard
	Scoreboard for calculating the score of players and finds the winner.
private LinkedBlockingQueue<Event> eventQueue
	To hold the events in the queue to be executed by table notifier. It is a blocking queue to make it thread safe wait for the queue to become non-empty when retrieving an element, and wait for space to become available in the queue when storing an element.
private Map<String, Socket> playerChannel
	playerChannel map holds the player session id as keys and Socket objects as values.
private HasMap<String, WonderBoard> wonders
	Hashmap for holding the id of the wonderboard and the wonderboard object
private String owner
	String that hold the owner of the table.
private boolean rollDice
	Becomes true when a player wants to roll a dice. It is assigned to false on each turn.
private TableNotifier notifier
	Sends notifications to websocket connections from table. Client side will receive these notifications.
Methods
public void playerJoined(String playerID, Socket socket)
	Method for taking the players inside the table and making their Websocket connection
public void init(int noOfPlayer, decks)
	Method for initializing the table. It will run when the table is created. It will determine the decks according to number of players and assign initial values for the table properties.
public void startTable()
	Method for starting the game. When owner push start button, the game will be started with this function.
public void rollDice()
	Method for rollingDice. It rolls a dice for the players who want to play rolling dice game.
public void addWonder()
	Method for adding a wonder to the table. According to number of players, init method will use this method for adding wonders to the table.
public void pickMagicCard(String wonderID)
	Method for choosing a magic card for the winner of rolling dice game.
public void changeHand()
	Method for changing the hands of players. This method will pass the remaining cards of the player to its neighbour at the end of every round.
public getHandRequest(String wonderID)
	This method is to get the hand of the wonder at current state with the given wonder id.
public WonderBoard viewStateRequest()
	This method is to return the WonderBoard of the current state.
public void diceRollRequest(String wonderID)
	Method for rolling dice request to for a given wonderboard.
public void notify()
	Method for notifying all players in table about games current status.
public void playAge()
	This method is called when an age of the game is finished and new age configuration must be handled.
public void lockAction(Action action)
	Method for putting the action into wonderboard to be executed at the end of each turn.
public boolean isPossible(Action action)
	Method for checking that the action is valid or not. If a player tries to make a valid action then table accepts it. In other case table does not give permission for the action.
public void playTurn()
	Method for playing the current turn in the table.

 */