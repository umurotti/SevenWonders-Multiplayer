import java.util.Map;

public class WonderBoard {

    private String name;
    private WonderBoard leftNeighbor;
    private WonderBoard rightNeighbor;
    private Map<String, Integer> sources;
    private Cost[] stageCosts = new Cost[3];
    private int currentStage;
    private Map<String, Card> builtCards;
    private int coin;
    private int diceValue;
    private Action lockedAction;
    private int defeatTokens;
    private int[] militaryTokens = new int[3];
    private Map <String, Integer> rightDiscount;
    private Map<String, Integer> leftDiscount;

    public WonderBoard(String name, WonderBoard leftNeighbor, WonderBoard rightNeighbor, Map<String, Integer> sources, Cost[] stageCosts, int currentStage, Map<String, Card> builtCards, int coin, int diceValue, Action lockedAction, int defeatTokens, int[] militaryTokens, Map<String, Integer> rightDiscount, Map<String, Integer> leftDiscount) {
        this.name = name;
        this.leftNeighbor = leftNeighbor;
        this.rightNeighbor = rightNeighbor;
        this.sources = sources;
        this.stageCosts = stageCosts;
        this.currentStage = currentStage;
        this.builtCards = builtCards;
        this.coin = coin;
        this.diceValue = diceValue;
        this.lockedAction = lockedAction;
        this.defeatTokens = defeatTokens;
        this.militaryTokens = militaryTokens;
        this.rightDiscount = rightDiscount;
        this.leftDiscount = leftDiscount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public WonderBoard getLeftNeighbor() {
        return leftNeighbor;
    }

    public void setLeftNeighbor(WonderBoard leftNeighbor) {
        this.leftNeighbor = leftNeighbor;
    }

    public WonderBoard getRightNeighbor() {
        return rightNeighbor;
    }

    public void setRightNeighbor(WonderBoard rightNeighbor) {
        this.rightNeighbor = rightNeighbor;
    }

    public Map<String, Integer> getSources() {
        return sources;
    }

    public void setSources(Map<String, Integer> sources) {
        this.sources = sources;
    }

    public Cost[] getStageCosts() {
        return stageCosts;
    }

    public void setStageCosts(Cost[] stageCosts) {
        this.stageCosts = stageCosts;
    }

    public int getCurrentStage() {
        return currentStage;
    }

    public void setCurrentStage(int currentStage) {
        this.currentStage = currentStage;
    }

    public Map<String, Card> getBuiltCards() {
        return builtCards;
    }

    public void setBuiltCards(Map<String, Card> builtCards) {
        this.builtCards = builtCards;
    }

    public int getCoin() {
        return coin;
    }

    public void setCoin(int coin) {
        this.coin = coin;
    }

    public int getDiceValue() {
        return diceValue;
    }

    public void setDiceValue(int diceValue) {
        this.diceValue = diceValue;
    }

    public Action getLockedAction() {
        return lockedAction;
    }

    public void setLockedAction(Action lockedAction) {
        this.lockedAction = lockedAction;
    }

    public int getDefeatTokens() {
        return defeatTokens;
    }

    public void setDefeatTokens(int defeatTokens) {
        this.defeatTokens = defeatTokens;
    }

    public int[] getMilitaryTokens() {
        return militaryTokens;
    }

    public void setMilitaryTokens(int[] militaryTokens) {
        this.militaryTokens = militaryTokens;
    }

    public Map<String, Integer> getRightDiscount() {
        return rightDiscount;
    }

    public void setRightDiscount(Map<String, Integer> rightDiscount) {
        this.rightDiscount = rightDiscount;
    }

    public Map<String, Integer> getLeftDiscount() {
        return leftDiscount;
    }

    public void setLeftDiscount(Map<String, Integer> leftDiscount) {
        this.leftDiscount = leftDiscount;
    }
}
  /*  WonderBoard Class
Attributes
private String name
        The name of the Wonder Board.
private WonderBoard leftNeighbor
        The left neighbor of the Wonder Board. For trading
        purposes.
private WonderBoard rightNeighbor
        The right neighbor of the Wonder Board. For trading
        purposes.
private Map<String, int> sources
        The complete list of every source the Wonder Board has.
        The Map will look like Figure[4]
<String type>
<int amount>
        “wood”
        3
        “stone”
        0
        “clay”
        0
        “ore”
        2
        “loom”
        1
        “papyrus”
        1
        “glass”
        0
        “shield”
        4
        “compass”
        2
        “tablet”
        1
        “gear”
        3
        “victoryPoint”
        12
        [Figure - 4] Example source map.


private Cost[3] stageCosts
        Every stage has different required costs. The first element
        in the array is for the 1st stage, second element is for the
        2nd stage and third for the 3rd.
private int currentStage
        A track/counter to keep what stage the Wonder Board is
        on.
private int coin
        Total amount of coins the Wonder Board has.
private int diceValue
        If the Wonder Board enters the Dice game, the rolled dice
        value of the board will be kept here. For later
        comparisons between other Wonder Boards.
private Map<String, Card> builtCards
        A map of previous built Cards. Since a Wonder Board
        can’t build the same card twice, this map will help us to
        both check and keep the card track for any other use.
        First key String is the name of the card and the second
        key Card is the instance of it.
private Action lockedAction
        The players choice, Action, will be held here for every
        Wonder Board. Since every Action is done at the end of
        the turn they were played and not instantly when they
        were played, we keep the Wonder Boards desired Action
        here and execute the contents of it at the end of the turn
        for each Wonder Board with the corresponding
        lockedAction’s.
private Map<String, int> leftDiscount
        This is like a menu for buying resources from neighbors.
        We keep this map because of the yellow cards which has
        discount effects in them. A typical map will look like this:

<String type>
<int goldCost>
        “wood”
        1
        “stone”
        1
        “clay”
        1
        “ore”
        1
        “loom”
        2
        “papyrus”
        2
        “glass”
        2

        [Figure - 5] Example map that means the player has built the   “West Trading Post” card which makes the cost of Raw materials 1 instead of 2 when buying from left neighbor.


private Map <String, int> rightDiscount
        Same with leftDiscount.
private int[3] militaryTokens
        Military tokens which a Wonder Board will get at the end
        of each age if they win the battle with their neighbors.
        Is an array with size 3 since each age’s military token
        gives different amount of Victory Points. (Age 1
        military token will give +1 VP, Age 2 +3 VP, Age 3
        +5 VP). Let’s say the array will look like [2,1,2]
        then the ScoreBoard class will give 2*1 + 1*3 + 2*5 =
        15 VP to the Wonder Board.
private int defeatTokens
        every defeat token will reduce -1 VP. A track of how many
        defeat tokens the Wonder Board has.
*/