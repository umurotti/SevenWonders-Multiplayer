/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.List;
import java.util.Map;

/**
 *
 * @author AkinParkan
 */
public class Card {
    private Cost cost;
    private String color;
    private String name;
    private List<String> freeBuildings;
    private Map<String,Integer> benefits;
    private int minNoOfPlayer;

    public Card(Cost cost, String color, String name, List<String> freeBuildings, int minNoOfPlayer, Map<String, Integer> benefits) {
        this.cost = cost;
        this.color = color;
        this.name = name;
        this.freeBuildings = freeBuildings;
        this.minNoOfPlayer = minNoOfPlayer;
        this.benefits = benefits;
    }

    public int getMinNoOFCount() {
        return minNoOfPlayer;
    }

    public void setCount(int minNoOfPlayer) {
        this.minNoOfPlayer = minNoOfPlayer;
    }

    public Cost getCost() {
        return cost;
    }

    public void setCost(Cost cost) {
        this.cost = cost;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getFreeBuildings() {
        return freeBuildings;
    }

    public void setFreeBuildings(List<String> freeBuildings) {
        this.freeBuildings = freeBuildings;
    }

    public void play(WonderBoard wb, String selection)
    {
        //
    }
}
