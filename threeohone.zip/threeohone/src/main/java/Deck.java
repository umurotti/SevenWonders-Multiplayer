import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Deck {
    private Card[] cards;
    private  String deckName;
    public Deck(Card[] cards,String deckName) {
        this.cards = cards;
        this.deckName =deckName;
    }
    public void shuffleCards()
    {
        List<Card> hold = Arrays.asList(cards);
        Collections.shuffle(hold);
        hold.toArray(cards);
    }
}
