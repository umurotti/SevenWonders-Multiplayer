/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cs319deneme3;

import io.swagger.annotations.Api;
import java.io.IOException;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import model.House;

/**
 *
 * @author umur
 */
    @Api("SW houseServices")
    @Path("SWhouseServices")
public class SWhouseServices {

    @GET
    //@Produces("application/json")
    @Produces("text/plain")
    @Path("createTableService")
    public String createTableService(@QueryParam("ownerID") String ownerID, @QueryParam("tableID") String tableID ) throws IOException {
        if (House.getInstance().createTable(ownerID, tableID) ) {;
        return "başarılı";
        } else {
            return "başarısız";
        }
    }
    
    @GET
    //@Produces("application/json")
    @Produces("text/plain")
    @Path("startTableService")
    public String startTableService(@QueryParam("tableID") String tableID ) throws IOException {
        if (House.getInstance().startTable(tableID) ) {
            return "başarılı";
        } else {
            return "başarısız";
        }
    }
}
