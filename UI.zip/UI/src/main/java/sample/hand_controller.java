package sample;

public class hand_controller {
}
