package sample;

public class join_game_controller {
}
