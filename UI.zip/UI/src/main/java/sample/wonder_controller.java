package sample;

public class wonder_controller {
}
